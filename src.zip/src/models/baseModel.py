import pandas as pd
import numpy as np
import sklearn as skl
import matplotlib.pyplot as plt

class Model:
  def __init__(self, preload = None, algorithm = "lrc"): # algorithm = one of ["lrc", "knn", "svm", "nbc"], preload = Some SKL model if want.
    self.model = preload if preload is not None else None
    self.trained = False
    self.algorithm = algorithm

  def train(self, data, epochs = 10000):
    Xtr, Ytr, Xval, Yval = data["train"]["X"], data["train"]["Y"], data["validation"]["X"], data["validation"]["Y"]#
    classes = np.unique(Ytr)

    #if not self.model:
    #  raise Exception("Please create the model first by calling `initModel(algorithm: str, preLoad)`")

    accuracies = []
    print(f"TRAINING {self.algorithm} MODEL WITH {Xtr.shape[0]} INSTANCES...")
    if self.algorithm in ["knn", "dtc", "rfc", "nbc"]:
      # recombine the training and validation sets as these models cant use validation sets
      #Xtr = np.vstack((Xtr, Xval))
      #Ytr = np.hstack((Ytr, Yval))
      self.model.fit(Xtr, Ytr)
      acc = skl.metrics.accuracy_score(Yval, self.model.predict(Xval))
      accuracies = [acc] * epochs

    elif self.algorithm == "xgb":
      self.model.set_params(
        n_estimators=1000,            # an upper bound
        eval_metric="error"           # classification error; accuracy = 1 - error
      )
      self.model.fit(Xtr, Ytr, eval_set=[(Xval, Yval)], verbose = True)

      # Get evals per round of xgb
      evals = self.model.evals_result_ if hasattr(self.model, "evals_result_") else self.model.evals_result()
      val_err = evals["validation_0"]["error"]
      accuracies = [1.0 - e for e in val_err] # find accuracies
      self.graphEpochAcc(accuracies, len(accuracies)) # graph

    else:
      for epoch in range(epochs):
        if epoch == 0:
          self.model.partial_fit(Xtr, Ytr, classes)
        else:
          self.model.partial_fit(Xtr, Ytr)

        Y = self.model.predict(Xval)
        accuracies.append(skl.metrics.accuracy_score(Yval, Y))
      self.graphEpochAcc(accuracies, epochs)

    self.trained = True
  
  def test(self, data):
    X, Y = data["test"]["X"], data["test"]["Y"]
    if not self.model: raise Exception("Please create the model first by calling `initModel(algorithm: str, preLoad)`")
    if not self.trained: raise Exception("Please train model first.")

    Ypred = self.model.predict(X)
    return self.compMetrics(Y, Ypred), Ypred
  
  def graphEpochAcc(self, accuracies, epochs):
    plt.plot(accuracies)
    plt.xlabel(f"Epoch({epochs})")
    plt.ylabel("Accuracy")
    plt.title("Accuracy Change With Epoch Number")
    print("ALOGIRTHM:", self.algorithm)
    plt.savefig(f'../results/learning curves/{self.algorithm}_AccGraph.png')
    plt.close()

  def compMetrics(self, Y, Ypred, average="weighted"):
    """
    Return a dict with common classification metrics.
    """
    return {
        "accuracy": skl.metrics.accuracy_score(Y, Ypred),
        "precision": skl.metrics.precision_score(Y, Ypred, average=average, zero_division=0),
        "recall": skl.metrics.recall_score(Y, Ypred, average=average, zero_division=0),
        "f1": skl.metrics.f1_score(Y, Ypred, average=average, zero_division=0),
        "confusion_matrix": skl.metrics.confusion_matrix(Y, Ypred),
        "classification_report": skl.metrics.classification_report(Y, Ypred),
    }


  def ppMetrics(self, Ytrue, Ypred, metrics, classLabels = ["alive", "dead"]):
    """
    Pretty-print a metrics dictionary, now with row/column totals.

    Parameters
    ----------
    metrics : dict
        Output of your evaluate() helper.
    classLabels : list[str] | tuple[str], optional
        Names for the classes, in the same order as the encoded
        confusion-matrix axes.
    """
    # ── overall scalar scores ───────────────────────────────────
    print("\n📊  Overall scores")
    print("-" * 60)
    for key in ("accuracy", "precision", "recall", "f1"):
      print(f"{key.capitalize():<12}: {metrics[key]:>8.4f}")

    # ── full sklearn classification report ─────────────────────
    print("\n📝  Sklearn classification report")
    print("-" * 60)
    print(metrics["classification_report"])

    # ── confusion matrix with totals ───────────────────────────
    print("\n📝  Sklearn classification report")
    print("-" * 60)
    print(metrics["classification_report"])

    # ── pandas confusion matrix with totals ────────────────────
    # If you want nicer column names, remap Ytrue / Ypred first.
    if classLabels is not None:
      label_map = {lbl: name for lbl, name in zip(sorted(set(Ytrue)), classLabels)}
      Ytrue_print = pd.Series(Ytrue).map(label_map)
      Ypred_print = pd.Series(Ypred).map(label_map)
    else:
      Ytrue_print = Ytrue
      Ypred_print = Ypred

    cm_df = pd.crosstab(
      pd.Series(Ytrue_print, name="Actual"),
      pd.Series(Ypred_print, name="Predicted"),
      margins=True,                       # adds totals
      dropna=False                        # include any missing classes
    )

    print("\n🔀  Confusion matrix (pandas)")
    print("-" * 60)
    print(cm_df.to_string())